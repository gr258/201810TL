#include "gtest/gtest.h"
#include "entry.h"

TEST(ENTRY,GIVEN_VALID_FILE_WHEN_READ_THEN_ENTRY_IS_VALID)
{
}

