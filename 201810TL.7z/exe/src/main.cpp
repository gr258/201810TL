#include <stdio.h>
#include "reader.h"

int main(int argc, char *argv[])
{
    if(argc < 2)
    {
        printf("Usage: %s [filename]\n",argv[0]);
    }
    else
    {
        reader r(argv[1]);
        r.show();
    }
    return 0;
}

